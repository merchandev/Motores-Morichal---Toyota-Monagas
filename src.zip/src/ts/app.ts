import Swiper from 'swiper'
import 'swiper/css'

// Slider principal de videos
const hero = document.querySelector('#custom-slider')
if (hero) {
  // eslint-disable-next-line no-new
  new Swiper('#custom-slider', {
    loop: false,
    navigation: { nextEl: '.cs-swiper-button-next', prevEl: '.cs-swiper-button-prev' },
    observer: true,
    observeParents: true,
  })
}

// Carrusel de vehículos
const vehiculos = document.querySelector('#vehiculos .toyota-slider')
if (vehiculos) {
  // eslint-disable-next-line no-new
  new Swiper('#vehiculos .toyota-slider', {
    spaceBetween: 20,
    navigation: {
      nextEl: '#vehiculos .toyota-arrow.swiper-button-next',
      prevEl: '#vehiculos .toyota-arrow.swiper-button-prev'
    },
    breakpoints: { 0:{slidesPerView:1}, 768:{slidesPerView:2}, 1024:{slidesPerView:3} }
  })
}

