/* Front-page interactions for Toyota Monagas theme */
(function(){
  function setHeaderOffset(){
    try {
      var header = document.querySelector('.site-header');
      var main = document.getElementById('site-main');
      if (!header) return;
      var h = header.offsetHeight || 0;
      document.documentElement.style.setProperty('--header-h', h + 'px');
      if (main) { main.style.paddingTop = ''; }
    } catch(e) {}
  }
  function revealOnView(){
    var headers = document.querySelectorAll('.section-header');
    var reveals = [];
    reveals.push.apply(reveals, document.querySelectorAll('#vehiculos .toyota-card'));
    reveals.push.apply(reveals, document.querySelectorAll('#info-mm .service-card'));
    reveals.push.apply(reveals, document.querySelectorAll('#productos-mm .producto-card'));
    reveals.push.apply(reveals, document.querySelectorAll('#blog-mm .blog-card'));

    reveals.forEach(function(el){ el.classList.add('reveal-on-scroll'); });

    if (!('IntersectionObserver' in window)) {
      headers.forEach(function(h){ h.classList.add('in-view'); });
      reveals.forEach(function(el){ el.classList.add('in'); });
      return;
    }

    var ioHeaders = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          ioHeaders.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    headers.forEach(function(h){ ioHeaders.observe(h); });

    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    reveals.forEach(function(el){ io.observe(el); });
  }
  function initHeroSlider(){
    var slider = document.getElementById('custom-slider');
    if (!slider || typeof Swiper === 'undefined') return;

    var slides = slider.querySelectorAll('.swiper-slide');
    var videos = slider.querySelectorAll('video');
    var progressSpans = slider.querySelectorAll('.cs-progress-bar span');

    var swiper = new Swiper('#custom-slider', {
      loop: true,
      navigation: { nextEl: '.cs-swiper-button-next', prevEl: '.cs-swiper-button-prev' },
      allowTouchMove: true,
      observer: true,
      observeParents: true,
      on: {
        init: function () { startAutoplay(this.realIndex); },
        slideChange: function () { startAutoplay(this.realIndex); }
      }
    });

    var autoplayTimer = null;
    var progressTimer = null;
    var paused = false; // solo afecta a slides de imagen
    var startTime = 0;
    var remaining = 0;
    var duration = 0;
    var lastVid = null;
    var lastHandlers = { timeupdate: null, ended: null, loadedmetadata: null };

    function clearTimers(){
      if (autoplayTimer) { clearTimeout(autoplayTimer); autoplayTimer = null; }
      if (progressTimer) { clearInterval(progressTimer); progressTimer = null; }
    }

    function resetBars(){ progressSpans.forEach(function(s){ s.style.width = '0%'; }); }

    function getSlideType(i){
      var s = slides[i]; if (!s) return 'video';
      return s.getAttribute('data-type') || (s.querySelector('video') ? 'video' : 'image');
    }

    function ensureVideoPlay(i){
      var s = slides[i]; if (!s) return;
      var vid = s.querySelector('video');
      if (vid) { try { vid.muted = true; vid.play().catch(function(){}); } catch(e){} }
    }

    function detachVideo(){
      if (lastVid) {
        try {
          if (lastHandlers.timeupdate) lastVid.removeEventListener('timeupdate', lastHandlers.timeupdate);
          if (lastHandlers.ended) lastVid.removeEventListener('ended', lastHandlers.ended);
          if (lastHandlers.loadedmetadata) lastVid.removeEventListener('loadedmetadata', lastHandlers.loadedmetadata);
        } catch(e){}
      }
      lastVid = null; lastHandlers = { timeupdate:null, ended:null, loadedmetadata:null };
    }

    function startAutoplay(index){
      // Detach any previous video listeners and timers
      detachVideo();
      clearTimers();
      resetBars();
      var totalBars = progressSpans.length || 1;
      var bar = progressSpans[index % totalBars];
      var type = getSlideType(index);
      if (type === 'video') {
        // Manejo por eventos de video
        var s = slides[index];
        var vid = s ? s.querySelector('video') : null;
        if (vid) {
          lastVid = vid;
          var fallback = 10; // si no hay metadata
          try {
            // Pausa cualquier otro video para evitar fugas de eventos y CPU
            videos.forEach(function(v){ if (v !== vid) { try { v.pause(); } catch(e){} } });
            vid.muted = true; vid.loop = false; vid.currentTime = 0; vid.play().catch(function(){});
          } catch(e){}

          lastHandlers.loadedmetadata = function(){
            // solo para asegurar que arranca con duración real
            if (!isFinite(vid.duration) || vid.duration <= 0) return;
          };
          vid.addEventListener('loadedmetadata', lastHandlers.loadedmetadata);

          lastHandlers.timeupdate = function(){
            var dur = (isFinite(vid.duration) && vid.duration > 0) ? vid.duration : fallback;
            var pct = Math.min(100, (vid.currentTime / dur) * 100);
            if (bar) bar.style.width = pct + '%';
          };
          vid.addEventListener('timeupdate', lastHandlers.timeupdate);

          lastHandlers.ended = function(){
            if (slider.matches(':hover')) {
              try { vid.currentTime = 0; vid.play().catch(function(){}); } catch(e){}
            } else {
              swiper.slideNext();
            }
          };
          vid.addEventListener('ended', lastHandlers.ended);
        }
      } else {
        // Slide de imagen: temporizador 7s, con pausa al hover
        duration = 7; startTime = Date.now(); remaining = duration * 1000; paused = false;
        progressTimer = setInterval(function(){
          if (paused) return;
          var elapsed = Date.now() - startTime;
          var pct = Math.min(100, (elapsed / (duration*1000)) * 100);
          if (bar) bar.style.width = pct + '%';
        }, 100);
        autoplayTimer = setTimeout(function(){ swiper.slideNext(); }, remaining);
      }
    }

    function pause(){
      // Pausa solo aplica a slides de imagen
      var index = swiper ? swiper.realIndex : 0;
      var type = getSlideType(index);
      if (type !== 'image') return;
      if (paused) return; paused = true;
      var elapsed = Date.now() - startTime;
      remaining = Math.max(0, (duration*1000) - elapsed);
      if (autoplayTimer) { clearTimeout(autoplayTimer); autoplayTimer = null; }
    }
    function resume(){
      var index = swiper ? swiper.realIndex : 0;
      var type = getSlideType(index);
      if (type !== 'image') return;
      if (!paused) return; paused = false;
      startTime = Date.now();
      autoplayTimer = setTimeout(function(){ swiper.slideNext(); }, remaining);
    }

    slider.addEventListener('mouseenter', pause);
    slider.addEventListener('mouseleave', resume);
  }

  function initVehiculos(){
    var wrapper = document.querySelector('#vehiculos .toyota-slider .swiper-wrapper');
    var templates = Array.from(document.querySelectorAll('#vehiculos .toyota-templates template'));
    var tabs = document.querySelectorAll('#vehiculos .toyota-tab');
    var tablist = document.querySelector('#vehiculos .toyota-tabs');
    var scroller = document.querySelector('#vehiculos .toyota-nav') || tablist;
    var indicator = document.querySelector('#vehiculos .toyota-tab-indicator');
    if (!wrapper || !templates.length || typeof Swiper === 'undefined') return;

    var swiper = new Swiper('#vehiculos .toyota-slider', {
      spaceBetween: 20,
      navigation: {
        nextEl: '#vehiculos .toyota-arrow.swiper-button-next',
        prevEl: '#vehiculos .toyota-arrow.swiper-button-prev'
      },
      breakpoints: { 0:{slidesPerView:1}, 768:{slidesPerView:2}, 1024:{slidesPerView:3} }
    });

    function buildSlides(category){
      var cat = category || 'all';
      wrapper.innerHTML = '';
      var items = templates.filter(function(t){
        var cats = (t.dataset.cat || '').trim().split(/\s+/);
        if (cat === 'all') return true;
        return (cats[0] || '') === cat;
      });
      items.forEach(function(tpl){
        var slide = document.createElement('div');
        slide.className='swiper-slide';
        var cloned = tpl.content.cloneNode(true);
        var card = cloned.querySelector('.toyota-card');
        if (card) {
          var cats = (tpl.dataset.cat || '').trim().split(/\s+/);
          card.setAttribute('data-cat', cats[0] || '');
        }
        slide.appendChild(cloned);
        wrapper.appendChild(slide);
      });
      swiper.update();
    }

    function moveIndicator(tab){
      if (!indicator || !tab) return;
      var rect = tab.getBoundingClientRect();
      var parentRect = tab.parentElement.getBoundingClientRect();
      // Indicador mÃ¡s corto (60% del ancho del tab) y centrado
      var width = Math.max(24, rect.width * 0.6);
      var offset = (rect.left - parentRect.left) + (rect.width - width) / 2;
      if (offset < 0) offset = 0; // evita posiciones negativas cuando el tab estÃ¡ parcialmente fuera de la vista
      indicator.style.width = width + 'px';
      indicator.style.transform = 'translateX(' + offset + 'px)';
    }

    function ensureTabInView(tab, align) {
      if (!scroller || !tab) return;
      // Solo aplicamos auto-scroll en tablet/mÃ³vil para mejorar UX
      if (!window.matchMedia('(max-width: 1024px)').matches) return;
      var tl = scroller;
      var tlRect = tl.getBoundingClientRect();
      var tRect = tab.getBoundingClientRect();
      // Calcular destino para que el tab quede al inicio o centrado
      var targetLeft = tl.scrollLeft + (tRect.left - tlRect.left);
      if (align === 'center') {
        targetLeft = targetLeft - (tlRect.width - tRect.width) / 2;
      }
      if (targetLeft < 0) targetLeft = 0;
      tl.scrollTo({ left: targetLeft, behavior: 'smooth' });
    }

    tabs.forEach(function(tab){
      tab.addEventListener('click', function(){
        var active = document.querySelector('#vehiculos .toyota-tab.is-active');
        if (active) active.classList.remove('is-active');
        tab.classList.add('is-active');
        buildSlides(tab.dataset.cat || 'all');
        moveIndicator(tab);
        ensureTabInView(tab, 'center');
      });
    });

    var activeTab = document.querySelector('#vehiculos .toyota-tab.is-active') || tabs[0];
    if (scroller) { scroller.scrollLeft = 0; }
    if (activeTab) {
      // Ejecutar despuÃ©s de pintar para que los rects sean correctos
      requestAnimationFrame(function(){
        ensureTabInView(activeTab, 'start');
        moveIndicator(activeTab);
      });
    }
    buildSlides('all');
  }

  function headerScroll(){
    var header = document.querySelector('.site-header');
    if (!header) return;
    var wasScrolled = window.scrollY > 10;
    function update(){
      var isScrolled = window.scrollY > 10;
      if (isScrolled && !wasScrolled) {
        header.classList.remove('no-anim');
        header.classList.add('scrolled');
      } else if (!isScrolled && wasScrolled) {
        // Al volver arriba, desactiva transiciones para evitar destello
        header.classList.add('no-anim');
        header.classList.remove('scrolled');
        setTimeout(function(){ header.classList.remove('no-anim'); }, 80);
      }
      wasScrolled = isScrolled;
    }
    update();
    window.addEventListener('scroll', update);
  }

  function headerMenuToggle(){
    var header = document.querySelector('.site-header');
    var btn = document.querySelector('.nav-toggle-modern') || document.querySelector('.nav-toggle');
    var menu = document.getElementById('site-menu');
    if (!header || !btn || !menu) return;
    btn.addEventListener('click', function(){
      var open = header.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      // actualiza el offset porque la altura del header puede cambiar en mÃ³vil
      setTimeout(setHeaderOffset, 100);
    });
    // Cerrar al navegar
    menu.addEventListener('click', function(e){
      if (e.target.tagName === 'A' && header.classList.contains('open')) {
        header.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
        setTimeout(setHeaderOffset, 100);
      }
    });
  }

  window.addEventListener('load', initHeroSlider);
  document.addEventListener('DOMContentLoaded', initVehiculos);
  document.addEventListener('DOMContentLoaded', revealOnView);
  document.addEventListener('DOMContentLoaded', headerScroll);
  document.addEventListener('DOMContentLoaded', headerMenuToggle);
  document.addEventListener('DOMContentLoaded', setHeaderOffset);
  document.addEventListener('DOMContentLoaded', function(){
    try {
      var placeholder = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'><rect fill='%23222' width='100%' height='100%'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='%23bbbbbb' font-family='Arial' font-size='24'>Imagen no disponible</text></svg>";
      document.querySelectorAll('#vehiculos .toyota-imgbox img, #sobre-nosotros img').forEach(function(img){
        img.addEventListener('error', function(){
          if (!img.dataset.fallback){ img.dataset.fallback = '1'; img.src = placeholder; }
        }, { once: true });
      });
      document.querySelectorAll('#custom-slider video').forEach(function(vid){
        var onError = function(){ try { vid.pause(); } catch(e){} vid.setAttribute('poster', placeholder); };
        vid.addEventListener('error', onError, { once: true });
        vid.addEventListener('stalled', onError, { once: true });
      });
    } catch(e){}
  });
  window.addEventListener('resize', setHeaderOffset);
})();
